#include "bitmap.c"
#include "hash.c"
#include "list.c"

#include "testlib.h"

int main (void) {

	char input[MAX_COM_STR];
	int input_result = 0;

	while (true) {

		int i = 0; char c;
	
		// Initialize
		input[0] = '\0';			
		for (i = 0; i < MAX_TOKEN; i++) {
			command_token[i][0] = '\0';
		} i = 0;

		// Input
		while ((c = getchar()) != '\n') {
			input[i++] = c;
		} input[i] = '\0';


		// Run Program
		input_result = command(input);
		if (input_result == -1) break;
	}


	return;
}

int command (const char *str) {

	// Tokenize
	int command_num = 0, command_result;
	char *token;

	command_result = 0;

	char temp[MAX_COM_STR];
	strcpy(temp,str);

	token = strtok(temp,token_spt);
	while (token != NULL) {
		strcpy(command_token[command_num++],token);

		token = strtok(NULL,token_spt);
	}

	if (strcmp(command_token[0],"quit") == 0) return -1;
	else if (strcmp(command_token[0],"create") == 0) {
		if (strcmp(command_token[1],"list") == 0) {
			create_func(command_token[2],command_token[1],0);	
		}
		else if (strcmp(command_token[1],"hashtable") == 0) {
			create_func(command_token[2],command_token[1],0);	
		}
		else if (strcmp(command_token[1],"bitmap") == 0) {
			int tp;
			sscanf(command_token[3],"%d",&tp);
			create_func(command_token[2],command_token[1],tp);
		}
	} else if (strcmp(command_token[0],"delete") == 0) {
		delete_func(command_token[1]);
	} else if (strcmp(command_token[0],"dumpdata") == 0) {
		dumpdata(command_token[1]);
	} else if (strcmp(command_token[0],"list_push_back") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		list_push(back,command_token[1],tp);
	} else if (strcmp(command_token[0],"list_push_front") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		list_push(front,command_token[1],tp);
	} else if (strcmp(command_token[0],"list_pop_back") == 0) {
		list_pop(back,command_token[1]);
	} else if (strcmp(command_token[0],"list_pop_front") == 0) {
		list_pop(front,command_token[1]);
	} else if (strcmp(command_token[0],"list_front") == 0) {
		list_print(front,command_token[1]);
	} else if (strcmp(command_token[0],"list_back") == 0) {
		list_print(back,command_token[1]);
	} else if (strcmp(command_token[0],"list_insert") == 0) {
		int tp,vp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);
		list_add(tp,vp,command_token[1]);
	} else if (strcmp(command_token[0],"list_insert_ordered") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		list_add_ordered(tp,command_token[1]);
	} else if (strcmp(command_token[0],"list_empty") == 0) {
		list_isEmpty(command_token[1]);		
	} else if (strcmp(command_token[0],"list_size") == 0) {
		list_isSize(command_token[1]);
	} else if (strcmp(command_token[0],"list_min") == 0) {
		list_minmax(min,command_token[1]);
	} else if (strcmp(command_token[0],"list_max") == 0) {
		list_minmax(max,command_token[1]);
	} else if (strcmp(command_token[0],"list_remove") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		list_idx_delete(tp,command_token[1]);
	} else if (strcmp(command_token[0],"list_reverse") == 0) {
		list_reverse(list_find(command_token[1]));
	} else if (strcmp(command_token[0],"list_sort") == 0) {
		list_sort(list_find(command_token[1]),list_less,NULL);
	} else if (strcmp(command_token[0],"list_splice") == 0) {
		int idx, bg, ed;
		sscanf(command_token[2],"%d",&idx);
		sscanf(command_token[4],"%d",&bg);
		sscanf(command_token[5],"%d",&ed);
		list_insertion(command_token[1],idx,command_token[3],bg,ed);
	} else if (strcmp(command_token[0],"list_unique") == 0) {
		if (command_token[2][0] == '\0') {
			list_unique(list_find(command_token[1]),NULL,list_less,NULL);
		} else {
			list_unique(list_find(command_token[1]),list_find(command_token[2]),list_less,NULL);
		}
	} else if (strcmp(command_token[0],"list_swap") == 0) {
		int tp, vp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);
		list_change(command_token[1],tp,vp);
	} else if (strcmp(command_token[0],"list_shuffle") == 0) {
		list_shuffle(list_find(command_token[1]));
	} else if (strcmp(command_token[0],"hash_insert") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		hash_addition(insert,command_token[1],tp);
	} else if (strcmp(command_token[0],"hash_replace") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		hash_addition(replace,command_token[1],tp);
	} else if (strcmp(command_token[0],"hash_empty") == 0) {
		hash_etc(empty,command_token[1]);
	} else if (strcmp(command_token[0],"hash_size") == 0) {
		hash_etc(size,command_token[1]);
	} else if (strcmp(command_token[0],"hash_clear") == 0) {
		hash_clear(hash_get(command_token[1]),hash_demolish);
	} else if (strcmp(command_token[0],"hash_delete") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		hash_deletion(command_token[1],tp);
	} else if (strcmp(command_token[0],"hash_apply") == 0) {
		if (strcmp(command_token[2],"square") == 0) {
			hash_apply(hash_get(command_token[1]),hash_square);
		} else if (strcmp(command_token[2],"triple") == 0) {
			hash_apply(hash_get(command_token[1]),hash_triple);
		}
	} else if (strcmp(command_token[0],"hash_find") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		hash_search(command_token[1],tp);
	} else if (strcmp(command_token[0],"bitmap_mark") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		bitmap_mark(bitmap_get(command_token[1]),tp);
	} else if (strcmp(command_token[0],"bitmap_none") == 0) {
		int tp, vp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);
		if (bitmap_none(bitmap_get(command_token[1]),tp,vp)) {
			printf("true\n");
		} else {
			printf("false\n");
		}
	} else if (strcmp(command_token[0],"bitmap_all") == 0) {
		int tp, vp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);
		if (bitmap_all(bitmap_get(command_token[1]),tp,vp)) {
			printf("true\n");
		} else {
			printf("false\n");
		}
	} else if (strcmp(command_token[0],"bitmap_any") == 0) {
		int tp, vp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);
		if (bitmap_any(bitmap_get(command_token[1]),tp,vp)) {
			printf("true\n");
		} else {
			printf("false\n");
		}
	} else if (strcmp(command_token[0],"bitmap_contains") == 0) {
		int tp, vp; bool bp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);

		if (strcmp(command_token[4],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[4],"false") == 0) {
			bp = false;
		}

		if (bitmap_contains(bitmap_get(command_token[1]),tp,vp,bp)) {
			printf("true\n");
		} else {
			printf("false\n");
		}
	} else if (strcmp(command_token[0],"bitmap_count") == 0) {
		int tp, vp; bool bp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);

		if (strcmp(command_token[4],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[4],"false") == 0) {
			bp = false;
		}

		printf("%u\n",bitmap_count(bitmap_get(command_token[1]),tp,vp,bp));
	} else if (strcmp(command_token[0],"bitmap_dump") == 0) {
		bitmap_dump(bitmap_get(command_token[1]));
	} else if (strcmp(command_token[0],"bitmap_expand") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);

		struct bitmap *current;
		current = bitmap_expand(bitmap_get(command_token[1]),tp);

		int i;
		for (i = 0; i < MAX_NODE; i++) {
			if (strcmp(bitmap_func[i].name,command_token[1]) == 0) {
				bitmap_func[i].node_bitmap = current;
				break;
			}
		}
	} else if (strcmp(command_token[0],"bitmap_set_all") == 0) {
		bool bp;
		if (strcmp(command_token[2],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[2],"false") == 0) {
			bp = false;
		}
		bitmap_set_all(bitmap_get(command_token[1]),bp);
	} else if (strcmp(command_token[0],"bitmap_flip") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		bitmap_flip(bitmap_get(command_token[1]),tp);
	} else if (strcmp(command_token[0],"bitmap_reset") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);
		bitmap_reset(bitmap_get(command_token[1]),tp);
	} else if (strcmp(command_token[0],"bitmap_scan") == 0) {
		int tp, vp; bool bp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);

		if (strcmp(command_token[4],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[4],"false") == 0) {
			bp = false;
		}
		printf("%u\n",bitmap_scan(bitmap_get(command_token[1]),tp,vp,bp));
	} else if (strcmp(command_token[0],"bitmap_scan_and_flip") == 0) {
		int tp, vp; bool bp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);

		if (strcmp(command_token[4],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[4],"false") == 0) {
			bp = false;
		}
		printf("%u\n",bitmap_scan_and_flip(bitmap_get(command_token[1]),tp,vp,bp));
	} else if (strcmp(command_token[0],"bitmap_set") == 0) {
		int tp; bool bp;
		sscanf(command_token[2],"%d",&tp);

		if (strcmp(command_token[3],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[3],"false") == 0) {
			bp = false;
		}
		bitmap_set(bitmap_get(command_token[1]),tp,bp);
	} else if (strcmp(command_token[0],"bitmap_set_multiple") == 0) {
		int tp, vp; bool bp;
		sscanf(command_token[2],"%d",&tp);
		sscanf(command_token[3],"%d",&vp);

		if (strcmp(command_token[4],"true") == 0) {
			bp = true;
		} else if (strcmp(command_token[4],"false") == 0) {
			bp = false;
		}

		bitmap_set_multiple(bitmap_get(command_token[1]), tp, vp, bp);
	} else if (strcmp(command_token[0],"bitmap_size") == 0) {
		printf("%u\n",bitmap_size(bitmap_get(command_token[1])));
	} else if (strcmp(command_token[0],"bitmap_test") == 0) {
		int tp;
		sscanf(command_token[2],"%d",&tp);

		if (bitmap_test(bitmap_get(command_token[1]),tp) == 0) {
			printf("false\n");
		} else {
			printf("true\n");
		}
	}

	return 0;
}



void hash_demolish (struct hash_elem *n, void *aux) {

	struct hash_node *current;
	current = hash_entry(n, struct hash_node, elem);

	free(current);

}

void hash_triple (struct hash_elem *n, void *aux) {

	struct hash_node *current;
	current = hash_entry(n, struct hash_node, elem);

	current->value *= current->value * current->value;

}

void hash_square (struct hash_elem *n, void *aux) {

	struct hash_node *current;
	current = hash_entry(n, struct hash_node, elem);

	current->value = current->value * current->value;

}

void hash_deletion(char *str, int value) {

	struct hash *current = hash_get(str);
	struct hash_node *find_node;
	find_node = (struct hash_node *)malloc(sizeof(struct hash_node));
	find_node->value = value;

	hash_delete(current,&find_node->elem);

}

void hash_etc (int mode, char *str) {

	struct hash *current = hash_get(str);

	if (mode == empty) {
		if (current->elem_cnt == 0) {
			printf("true\n");
		} else {
			printf("false\n");
		}
	} else if (mode == size) {
		printf("%d\n",current->elem_cnt);
	}

}

void hash_search (char *str, int value) {

	struct hash *current = hash_get(str);
	struct hash_node *find_node;
	find_node = (struct hash_node *)malloc(sizeof(struct hash_node));
	find_node->value = value;

	struct hash_elem *find_elem;

	if ((find_elem = hash_find(current,&find_node->elem)) != NULL) {
		printf("%d\n",hash_entry(find_elem, struct hash_node, elem)->value);
	}

}

void hash_addition (int mode, char *str, int value) {

	struct hash_node *new_node;
	new_node = (struct hash_node *)malloc(sizeof(struct hash_node));
	new_node->value = value;

	struct hash *current;
	current = hash_get(str);

	if (mode == insert) {
		hash_insert(current,&new_node->elem);
	} else if (mode == replace) {
		hash_replace(current,&new_node->elem);
	}

}

void list_change (char *str, int a, int b) {

	struct list_elem *elem_a, *elem_b;
	struct list *current;
	current = list_find(str);

	int i;
	l = list_begin(current);
	for (i = 0; l != list_end(current); l = list_next(l), i++) {
		if (i == a) elem_a = l;
		if (i == b) elem_b = l;
	}

	list_swap(elem_a,elem_b);

}

void list_insertion (char *str1, int idx, char *str2, int begin, int end) {

	struct list_elem *elem_idx, *elem_begin, *elem_end;
	struct list *target, *into;
	target = list_find(str1);
	into = list_find(str2);

	int i;
	l = list_begin(target);
	for (i = 0; l != list_end(target); l = list_next(l), i++) {
		if (i == idx) {
			elem_idx = l;
		}
	}

	l = list_begin(into);
	for (i = 0; l != list_end(into); l = list_next(l), i++) {
		if (i == begin) {
			elem_begin = l;	
		}
		if (i == end) {
			elem_end = l;
		}
	}

	list_splice(elem_idx,elem_begin,elem_end);

}

unsigned hash_function (const struct hash_elem *e, void *aux) {

	int value = hash_entry(e,struct hash_node,elem)->value;
	return hash_int(value);

}

bool hash_less (const struct hash_elem *a, const struct hash_elem *b, void *aux) {

	if (hash_entry(a,struct hash_node,elem)->value < hash_entry(b,struct hash_node,elem)->value) {
		return true;
	} else {
		return false;
	}

}

bool list_less (const struct list_elem *a, const struct list_elem *b, void *aux) {

	if (list_entry(a,struct node,elem)->value < list_entry(b,struct node,elem)->value) {
		return true;
	} else {
		return false;
	}

}

void list_idx_delete (int idx, char *str) {

	int i;
	struct list *current;
	current = list_find(str);

	l = list_begin(current);
	for (i = 0; l != list_end(current); i++) {
		if (idx == i) {
			l = list_remove(l);
		} else {
			l = list_next(l);
		}
	}

}

void list_minmax (int mode, char *str) {

	struct list *current;
	current = list_find(str);

	if (mode == min) {
		int min = MAX;
		l = list_begin(current);
		for (; l != list_end(current); l = list_next(l)) {
			if (min > list_entry(l, struct node, elem)->value) {
				min  = list_entry(l, struct node, elem)->value;	
			}
		}
		printf("%d\n",min);

	} else if (mode == max) {
		int max = MIN;
		l = list_begin(current);
		for (; l != list_end(current); l = list_next(l)) {
			if (max < list_entry(l, struct node, elem)->value) {
				max = list_entry(l, struct node, elem)->value;
			}
		}
		printf("%d\n",max);

	}

}

void list_isSize (char *str) {

	struct list *current;
	current = list_find(str);

	printf("%d\n",list_size(current));

	return;	

}

void list_isEmpty (char *str) {

	struct list *current;
	current = list_find(str);

	if (list_begin(current) == list_end(current)) {
		printf("true");
	} else {
		printf("false");
	}
	printf("\n");

	return;

}

struct list* list_find (char *str) {
 
	if (str[0] != '\0') {

	int i;
	for (i = 0; i < MAX_NODE; i++) {
		if (strcmp(str,list_func[i].name) == 0) {
			return &list_func[i].node_list;
		}
	}

	}

	printf("[ERROR] There is no such data. Program can be terminated\n\n");

	return NULL;

}

struct bitmap* bitmap_get (char *str) {
	
	if (str[0] != '\0') {

	int i;
	for (i = 0; i < MAX_NODE; i++) {
		if (strcmp(str,bitmap_func[i].name) == 0) {
			return bitmap_func[i].node_bitmap;
		}
	}

	}

	printf("[ERROR] There is no such data. Program can be terminated\n\n");

	return NULL;

}

struct hash* hash_get (char *str) {

	if (str[0] != '\0') {

	int i;
	for (i = 0; i < MAX_NODE; i++) {
		if (strcmp(str,hash_func[i].name) == 0) {
			return &(hash_func[i].node_hash);
		}
	}

	}

	printf("[ERROR] There is no such data. Program can be terminated\n\n");

	return NULL;
}

void list_add_ordered (int value, char *str) {

	int i;
	struct list *current;
	current = list_find(str);

	l = list_begin(current);
	for (i = 0; l != list_end(current); l = list_next(l), i++) {
		if (list_entry(l,struct node,elem)->value >= value) {
			break;
		}
	}

	list_add(i, value, str);

}

void list_add (int idx, int value, char *str) {

	int i;
	struct list *current;
	current = list_find(str);

	l = list_begin(current);
	for (i = 0; l != list_end(current); l = list_next(l), i++) {
		if (i == idx) break;
	}

	struct node *new_node = (struct node *)malloc(sizeof(struct node));
	new_node->value = value;

	if (l->next == NULL || l == NULL) {
		list_push_back(current,&(new_node->elem));
	} else {
		list_insert(l,&(new_node->elem));
	}

	return;

}

void list_push (int mode, char *str, int value) {

	int i;
	struct list *current;
	current = list_find(str);

	if (mode == back) {
		struct node *new_node = (struct node *)malloc(sizeof(struct node));
		new_node->value = value;

		list_push_back(current,&new_node->elem);
	} else  if (mode == front) {
		struct node *new_node = (struct node *)malloc(sizeof(struct node));
		new_node->value = value;

		list_push_front(current,&new_node->elem);
	}

	return;

}

void list_pop (int mode, char *str) {

	int i;
	struct list *current;
	current = list_find(str);

	if (mode == back) {
		struct node *pop_node = list_entry(list_pop_back(current), struct node, elem);
		free(pop_node);
	} else if (mode == front) {
		struct node *pop_node = list_entry(list_pop_front(current), struct node, elem);
		free(pop_node);
	}

	return;

}

void list_print (int mode, char *str) {

	int i;
	struct list *current;
	current = list_find(str);

	if (mode == back) {
		struct node *print_node = list_entry(list_back(current), struct node, elem);
		printf("%d\n",print_node->value);
	} else if (mode == front) {
		struct node *print_node = list_entry(list_front(current), struct node, elem);
		printf("%d\n",print_node->value);
	}

}

void create_func (char *str, char *strct, int size) {
	
	if (strcmp(strct,"list") == 0) {
		strcpy(list_func[list_func_num].name,str);
		list_init(&list_func[list_func_num].node_list);
		list_func_num++;
	} else if (strcmp(strct,"hashtable") == 0) {
		strcpy(hash_func[hash_func_num].name,str);
		hash_init(&hash_func[hash_func_num].node_hash,hash_function,hash_less,NULL);
		hash_func_num++;
	} else if (strcmp(strct,"bitmap") == 0) {
		strcpy(bitmap_func[bitmap_func_num].name,str);
		bitmap_func[bitmap_func_num].node_bitmap = bitmap_create(size);
		bitmap_func_num++;
	}

	return;
}

void delete_func (char *str) {

	int i;
	for (i = 0; i < MAX_NODE; i++) {
		if (strcmp(list_func[i].name,str) == 0) {
			l = list_begin(&list_func[i].node_list);
			for (; l != list_end(&list_func[i].node_list);) {
				struct node *current = list_entry(l, struct node, elem);
				l = list_remove(l);
				free(current);
			}
			list_func[i].name[0] = '\0';
			break;
		}
		if (strcmp(hash_func[i].name,str) == 0) {
			hash_destroy(&hash_func[i].node_hash,hash_demolish);
			hash_func[i].name[0] = '\0';			
			break;
		}
		if (strcmp(bitmap_func[i].name,str) == 0) {
			bitmap_destroy(bitmap_func[i].node_bitmap);
			bitmap_func[i].name[0] = '\0';
			break;
		}
	}
}

void dumpdata (char *str) {

	int i, j;
	for (i = 0; i < MAX_NODE; i++) {
		if (strcmp(list_func[i].name,str) == 0) {
			l = list_begin(&list_func[i].node_list);
			for (j = 0; l != list_end(&list_func[i].node_list); l = list_next(l), j++) {
				struct node *current = list_entry(l, struct node, elem);
				if (l != list_begin(&list_func[i].node_list))
					printf(" ");
				printf("%d",current->value);
			}
			if (j != 0) printf("\n");
			break;
		}
		if (strcmp(hash_func[i].name,str) == 0) {
			struct hash_iterator hi;
			int j = 0;

			hash_first(&hi,&hash_func[i].node_hash);
			while (hash_next(&hi)) {
				j++;
				struct hash_node *current = hash_entry(hash_cur(&hi), struct hash_node, elem);

				printf("%d ",current->value);
			}
			if (j != 0) printf("\n");
			break;
		}
		if (strcmp(bitmap_func[i].name,str) == 0) {
			for (j = 0; j < bitmap_size(bitmap_func[i].node_bitmap); j++) {
				printf("%d",bitmap_test(bitmap_func[i].node_bitmap, j));
			}
			if (j != 0) printf("\n");
			break;
		}
	}
}
