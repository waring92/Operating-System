#include <stdio.h>
#include <string.h>

#define MAX_COM_STR 50
#define MAX 0x7FFFFFFF
#define MIN 0x80000000
#define MAX_TOKEN 10
#define MAX_NODE 20

enum list_command {
	back = 1,
	front,
	min,
	max,
	insert,
	replace,
	empty,
	size
};

// LIST
int list_func_num = 0;
struct list_function {
	char name[MAX_COM_STR];
	struct list node_list;
}list_func[MAX_NODE];
struct list_elem *l;

// HASH
struct hash_node {
	struct hash_elem elem;
	int value;
};

int hash_func_num = 0;
struct hash_function {
	char name[MAX_COM_STR];
	struct hash node_hash;
}hash_func[MAX_NODE];
struct hash_elem *h;

// BIT MAP
int bitmap_func_num = 0;
struct bitmap_function {
	char name[MAX_COM_STR];
	struct bitmap *node_bitmap;
}bitmap_func[MAX_NODE];
struct elem_type *b;

char token_spt[] = " \t";
char command_token[MAX_TOKEN][MAX_COM_STR];

int command (const char *);
int command_idx (const char *);

struct bitmap* bitmap_get (char *);

void hash_demolish(struct hash_elem *, void *);
void hash_triple(struct hash_elem *, void *);
void hash_square(struct hash_elem *, void *);
void hash_deletion(char *, int);
void hash_etc(int, char *);
void hash_search(char *, int);
void hash_addition(int, char *,int);
unsigned hash_function (const struct hash_elem *,void *);
bool hash_less (const struct hash_elem *, const struct hash_elem*, void *);
struct hash* hash_get (char *);

bool list_less (const struct list_elem*, const struct list_elem*, void *);
struct list* list_find (char *);
void list_change(char *, int, int);
void list_insertion(char *,int,char *,int,int);
void list_idx_delete(int, char *);
void list_minmax(int, char *);
void list_isEmpty(char *);
void list_isSize(char *);
void list_push (int,char *,int);
void list_pop (int,char *);
void list_print (int,char *);
void list_add (int,int,char *);
void list_add_ordered (int,char *);

void create_func (char *, char *, int);
void delete_func (char *);
void dumpdata (char *);
