#include <list.h>
#include "filesys/file.h"
#include "threads/thread.h"
#include "threads/synch.h"

struct page {

	int idx;

	struct list_elem elem;

	uint8_t *upage;
	void *kpage;

	struct file *file;
	char file_name[100];
	struct thread *thread;

	uint32_t read_bytes;
	uint32_t zero_bytes;

	off_t ofs;
	bool writable;	

};

void page_new (uint8_t*, struct file *, off_t, bool,
	       uint32_t, uint32_t);
struct list_elem* page_find (uint8_t*);
