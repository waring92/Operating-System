#include <stdio.h>
#include <stdlib.h>
#include "threads/malloc.h"
#include "vm/page.h"
#include "filesys/file.h"
#include "threads/thread.h"
#include "threads/synch.h"

static int count = 0;
static struct semaphore page_lock;
static bool page_init = false;

void page_new (uint8_t *upage, struct file *file, off_t ofs,
	       bool writable, uint32_t read, uint32_t zero) {
	if (page_init == false) {
		sema_init(&page_lock, 1);
		page_init = true;
	}	

	sema_down(&page_lock);

	struct thread *current = thread_current();
	struct page *new = (struct page *)malloc(sizeof(struct page));

	//printf("Page generating..\n");

	new->idx = count++;
	new->upage = upage;
	new->file = file;
	new->ofs = ofs;
	new->read_bytes = read;
	new->zero_bytes = zero;
	new->writable = writable;

	list_push_back(&current->page, &new->elem);

	sema_up(&page_lock);

	return;


}


struct list_elem* page_find (uint8_t *upage) {

	struct list_elem *e;
	struct thread *current = thread_current();

	for (e = list_begin(&current->page);
	     e!= list_end(&current->page);
  	     e = list_next(e)) {

		struct page *p = (struct page *)list_entry(e, struct page, elem);
		
		//printf("\t\t[%s] : [%d] page\n",current->name, p->idx);

		if (upage == p->upage) {
			return e;
		}

	}

	return NULL;

} 
