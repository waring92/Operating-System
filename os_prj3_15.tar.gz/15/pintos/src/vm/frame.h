#include <list.h>
#include "threads/thread.h"
#include "threads/synch.h"

struct frame {

	void *paddr, *upage;
	struct thread *thread;
	bool reference;
	struct list_elem elem;

};

void init (void);
void* frame_new (void *, bool);
void frame_free (void *);
