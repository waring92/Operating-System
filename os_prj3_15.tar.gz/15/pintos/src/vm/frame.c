#include <stdio.h>
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "frame.h"
#include "userprog/process.h"
#include "userprog/syscall.h"

static struct semaphore frame_lock;
static struct list frame_list;

static bool is_first = false;

void init (void) {

	sema_init(&frame_lock,1);
	list_init(&frame_list);

//	printf("\t\tframe.c : initialization!\n");

	is_first = true;

}

void* frame_new (void *upage, bool mode) {

	if (is_first == false) init();

	void *kpage;
	struct thread *current = thread_current();

	sema_down(&frame_lock);

	// mode selection
	if (mode) {
		//printf("this is mode true\n");
		kpage = palloc_get_page(PAL_USER|PAL_ZERO);
	} else {
		kpage = palloc_get_page(PAL_USER);
	}

	struct frame *fr;

	if (kpage == NULL) {

		printf("Can not get more kernel page!\n");

	} else {

		fr = (struct frame *) malloc (sizeof(struct frame));
		fr->reference = false;
		fr->thread = current;
		fr->paddr = kpage;
		fr->upage = upage;

		list_push_front(&frame_list, &fr->elem);	

	}

	sema_up(&frame_lock);

	return kpage;

}

void frame_free (void *kpage) {

//	struct thread *current = thread_current();
	struct list_elem *e;

	sema_down(&frame_lock);

	for (e = list_begin(&frame_list);
	     e !=list_end(&frame_list);
	     e = list_next(e)) {

		struct frame *f = (struct frame *)list_entry(e, struct frame, elem);

		if (kpage == f->paddr) {
			palloc_free_page(kpage);
			list_remove(&f->elem);
		}
	}
	sema_up(&frame_lock);

	return;
}
