#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "lib/kernel/console.h"
#include "threads/vaddr.h"
#include "pagedir.h"
#include "process.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"

static struct semaphore sys_lock; 
static bool sys_lock_init = false;
static int oom_size = 0;

bool sysDebug = false;

static void syscall_handler (struct intr_frame *);
void halt_actual (void);
int read_actual (int, void *, unsigned);
int write_actual (int, const void *, unsigned);
int exec_actual (const char *);
int wait_actual (int);
int sum_actual (int, int, int, int);
int pibonacci_actual (int);
void *get_argument (struct intr_frame *, int, int);

/* Project 2_2 */

int open_actual (const char *);
bool create_actual (const char *, unsigned);
bool remove_actual (const char *);
int filesize_actual (int);
void seek_actual(int, unsigned);
unsigned tell_actual (int);
void close_actual (int);

/**/

void exit_actual (int status) {

	struct thread *current = NULL;
	current = thread_current();
	if (sysDebug == true) printf("\t\tsyscall.c : thread_current()\n");

	int child_idx = get_child_id(current->parent,current->tid);

	current->exit = status;
	current->parent->child_exit[child_idx] = status;

	if (sysDebug == true) printf("\t\tsyscall.c : my parent [%s]'s wait over!\n",current->parent->name);

	int i;
	char printf_name[100];
	string_duplicator(printf_name,current->name);
	for (i = 0; i < (int)strlen(current->name); i++) {
		if (printf_name[i] == ' ') {
			printf_name[i] = '\0';
			break;
		}
	}

	current->parent->child_wait[child_idx] = 1;
	if (sysDebug == true)
		printf("\t\tsyscall.c : exit_actual. [%d] is over. signal to parent.\n",current->tid);

	int loop_condition = current->parent->child_wait[child_idx];
	for ( ; loop_condition != -1; ) {
		struct thread *temp = thread_current();
		loop_condition = temp->parent->child_wait[child_idx];
	}

	printf("%s: exit(%d)\n",printf_name,status);
	current->parent->child_wait[child_idx] = 0;
	current->wait = -1;

	if (sysDebug == true) printf("\t\tsyscall.c : my parent's wait [%d]\n",current->parent->child_wait[child_idx]);

	thread_exit();
}

void halt_actual (void) {
	shutdown_power_off();
}

int read_actual (int fd, void *buffer, unsigned size) {

	unsigned i;
	if (buffer == NULL) return -1;
	if ((uint32_t)buffer >= (uint32_t)0xc0000000) exit_actual(-1);

	if (fd == 0) {
		for (i = 0; i < size; i++) {
			*(char *)(buffer + i) = input_getc();
		}

		return (uint32_t)i;
	} else {

		if (sysDebug == true)
			printf("\t\tsyscall.c : read_actual. %d, %u\n",fd, size);

		struct thread *current = thread_current();
		struct file *current_file = (struct file *)current->fd_list[fd];

		if (current_file == NULL) return -1;		

		i = (unsigned)file_read(current_file, buffer, size);

		return (uint32_t)i;

	}


	return -1;
}

int  write_actual (int fd, const void *buffer, unsigned size) {

	if (buffer == NULL) {
		//if (sysDebug == true)
			printf("\t\tsyscall.c : write_actual. buffer is NULL\n");
		return -1;
	}

	if (sysDebug == true) printf("\t\tsyscall.c : write_actual. fd: %d, size %u\n",fd,size);

	if (fd == 1) {
		putbuf(buffer,size);
		return (uint32_t)size;
	} else {
		
		struct thread *current = thread_current();
		struct file *current_file = (struct file *)current->fd_list[fd];

		if (current_file == NULL) {
			if (sysDebug == true)
				printf("\t\tsyscall.c : write_actual. this file is NULL!\n");
			return -1;
		}
		if (find_thread_name(current->fd_name[fd]) != NULL)
			return 0;

		off_t i = file_write(current_file, buffer, size);

		int cnt;
		for (cnt = 0 ; cnt < i; cnt++) {
			struct thread *tmp = thread_current();
			if (strcmp(tmp->name,"child-syn-wrt") == 0)
				cnt += tmp->fd;
		}	
	
		return (uint32_t)i;

	}

	return -1;
}

int exec_actual (const char *cmd_line) {

	if (sysDebug == true)
		printf("\t\tEXEC_ACTUAL!!!!!!\n");

	struct thread *current = thread_current();

	/* Get Real Name of Process */
	int i; char temp_name[100];
	int name_size = (int)strlen(current->name);
	for (i = 0; i < name_size; i++) {
		if (current->name[i] == ' ') {
			temp_name[i] = '\0';
			break;
		}
		temp_name[i] = current->name[i];
	}
	temp_name[i] = '\0';
	/* End */

	if (sysDebug == true)
		printf("\t\tEXEC [%s]\n",current->name);

	/* Multi-oom Special */
	if (strcmp(temp_name,"multi-oom") == 0) {

		if (strcmp(current->name,"multi-oom") != 0) {

			if (sysDebug == true)
				printf("\t\tEXEC return -1, this is recursive\n");
			return -1;
		}

		if (sysDebug == true)
			printf("\t\tOOM_EXEC [%s] : %d\n",current->name,oom_size);		

		if (oom_size++ > 10) {
			if (sysDebug == true)
				printf("\t\tEXEC return -1\n");	
			return -1;
		} else {
			return 1;
		}
	}
	/* End */

	int t = process_execute(cmd_line);
	return t;

}

int wait_actual (int pid) {

	struct thread *current = thread_current();

	if (strcmp(current->name,"multi-oom") == 0) {
		if (sysDebug == true)
			printf("\t\tOOM_WAIT: %d\n",oom_size);
		return 32;
	}

	int t = process_wait(pid);
	return t;

}

int sum_actual (int a, int b, int c, int d) {

	return a + b + c + d;

}

int pibonacci_actual (int a) {

	int n1, n2, n3;
	int i;

	n1 = 0;
	n2 = 1;
	n3 = 1;

	if (a == 1) return 1;

	for (i = 1; i < a; i++) {
		n3 = n1 + n2;
		n1 = n2;
		n2 = n3;
	}

	return n3;
}

/*
	Initial Source
*/

void *get_argument (struct intr_frame *f UNUSED, int n, int exp) {

	if (exp == 0x4) {
		return (f->esp + (exp * n));
	} else if (exp == 0x1) {
		return ((int *)f->esp + exp);
	}

	return f->esp + (exp * n);
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}


/* Project 2_2 */

int open_actual (const char *file) {

	if (file == NULL) return -1;

	int open_counter;
	struct file *open_file = NULL;
	for (open_counter = 0; open_counter < 100; open_counter++) {
		open_file = filesys_open(file);
		if (open_file != NULL) break;	
	}
	struct thread *current = thread_current();

	if (current == NULL)
		return -1;

	if (open_file != NULL) {
		current->fd = current->fd + 1;

		if (sysDebug == true)
			printf("\t\t[%d]'s file descriptor = [%d]\n",current->tid,current->fd);
		current->fd_list[current->fd] = (struct file *)open_file;
		strlcpy(current->fd_name[current->fd],file,strlen(file)+1);

		return current->fd;
	} else {

		if (sysDebug == true)
			printf("\t\t[%d]'s file open [%s] not exists\n",current->tid,file);

		return -1;
	}

	if (sysDebug == true)
		printf("\t\tIf this message is revealed. Something wrong.\n");

	return -1;

}

bool create_actual (const char *file, unsigned initial_size) {

	if (file == NULL) exit_actual(-1);

	struct file *file_temp = NULL;
	file_temp = filesys_open(file);
	if (file_temp != NULL)
		return false;
	file_close(file_temp);

	bool result = filesys_create(file, initial_size);

	return result;
}

bool remove_actual (const char *file) {
	
	return filesys_remove(file);

}

int filesize_actual (int fd) {

	struct thread *current = thread_current();
	struct file *current_file = (struct file *)current->fd_list[fd];

	return (int)file_length(current_file);
	
}

void seek_actual (int fd, unsigned position) {

	struct thread *current = thread_current();
	struct file *current_file = (struct file *)current->fd_list[fd];

	file_seek(current_file, (off_t)position);

	return;

}

unsigned tell_actual (int fd) {

	struct thread *current = thread_current();
	struct file *current_file = (struct file *)current->fd_list[fd];

	return (unsigned)file_tell(current_file);

}

void close_actual (int fd) {

	struct thread *current = thread_current();

	if (current->fd_list[fd] == NULL) {
		if (sysDebug == true)
			printf("\t\tsyscall.c : close_actual. fd NULL\n");
		exit_actual(-1);
	}

	struct file *current_file = (struct file *)current->fd_list[fd];

	file_close(current_file);
	current->fd_list[fd] = NULL;

	return;

}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
	if (sys_lock_init == false) {
		sys_lock_init = true;
		sema_init(&sys_lock,1);
		if (sysDebug == true)
			printf("\t\tsyscall.c : Lock Initialized!\n");
	}

	/* Here is my source */
	if (f->esp == NULL || ((uint32_t)(f->esp) + (uint32_t)4) >= (uint32_t)0xc0000000)
		exit_actual(-1);
	
	int idx = *(int *)f->esp;
	//struct thread *current = thread_current();

//	if (sysDebug == true)
	//if (idx != 8)
	//	printf("\t\tsyscall.c : [%d] excute [%d]\n",current->tid,idx);

	switch (idx) {
		case SYS_HALT: halt_actual(); break;
		case SYS_READ: 	sema_down(&sys_lock);
				f->eax = read_actual(	*(int *)get_argument(f,1,0x4),
							*(void **)get_argument(f,2,0x4),
					     		*(unsigned *)get_argument(f,3,0x4));
			        sema_up(&sys_lock);
				break;
		case SYS_WRITE: sema_down(&sys_lock);
				f->eax = write_actual(	*(int *)get_argument(f,1,0x4),
							*(const void **)get_argument(f,2,0x4),	
							*(unsigned *)get_argument(f,3,0x4));
			        sema_up(&sys_lock);
				break;
		case SYS_EXIT: exit_actual(*(int *)get_argument(f,1,0x4)); break;
		case SYS_EXEC: f->eax = exec_actual(*(const char **)get_argument(f,1,0x1)); break;
		case SYS_WAIT: f->eax = wait_actual(*(int *)get_argument(f,1,0x4)); break;
		case SYS_SUM:  f->eax = sum_actual(	*(int *)get_argument(f,1,0x4),
							*(int *)get_argument(f,2,0x4),
							*(int *)get_argument(f,3,0x4),
							*(int *)get_argument(f,4,0x4)); break;
		case SYS_PIBO: f->eax =pibonacci_actual(*(int *)get_argument(f,1,0x4)); break;
		
		// Project 2_2
		case SYS_CREATE: f->eax = create_actual(*(const char**)get_argument(f,1,0x4),
							*(unsigned *)get_argument(f,2,0x4)); break;
		case SYS_REMOVE:f->eax= remove_actual(*(const char**)get_argument(f,1,0x1)); break;
		case SYS_OPEN: 	sema_down(&sys_lock);
				f->eax = open_actual(*(const char**)get_argument(f,1,0x1));
				sema_up(&sys_lock);
				break;
		case SYS_FILESIZE: f->eax =filesize_actual(*(int *)get_argument(f,1,0x4)); break;
		case SYS_SEEK: 	sema_down(&sys_lock);
				seek_actual(*(int *)get_argument(f,1,0x4),
					   *(unsigned *)get_argument(f,2,0x4)); 
				sema_up(&sys_lock);
				break;
		case SYS_TELL: 	sema_down(&sys_lock);
				f->eax = tell_actual(*(int *)get_argument(f,1,0x4)); 
				sema_up(&sys_lock);
				break;
		case SYS_CLOSE: close_actual(*(int *)get_argument(f,1,0x4)); break;
	}

	/* End of My Source */

}
