#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "lib/kernel/console.h"
#include "threads/vaddr.h"
#include "pagedir.h"
#include "process.h"

bool sysDebug = false;

static void syscall_handler (struct intr_frame *);
void halt_actual (void);
int read_actual (int, void *, unsigned);
int write_actual (int, const void *, unsigned);
int exec_actual (const char *);
int wait_actual (int);
int sum_actual (int, int, int, int);
int pibonacci_actual (int);
void *get_argument (struct intr_frame *, int, int);

void exit_actual (int status) {

	struct thread *current = NULL;
	current = thread_current();
	if (sysDebug == true) printf("\t\tsyscall.c : thread_current()\n");

	current->exit = status;
	current->wait = -1;
	current->parent->child_exit = status;

	if (sysDebug == true) printf("\t\tsyscall.c : my parent [%s]'s wait over!\n",current->parent->name);

	int i;
	char printf_name[100];
	string_duplicator(printf_name,current->name);
	for (i = 0; i < (int)strlen(current->name); i++) {
		if (printf_name[i] == ' ') {
			printf_name[i] = '\0';
			break;
		}
	}

	printf("%s: exit(%d)\n",printf_name,status);

	current->parent->wait = 1;
	if (sysDebug == true) printf("\t\tsyscall.c : my parent's wait [%d]\n",current->parent->wait);

	thread_exit();
}

void halt_actual (void) {
	shutdown_power_off();
}

int read_actual (int fd, void *buffer, unsigned size) {

	unsigned i;
	if (buffer == NULL) return -1;

	if (fd == 0) {
		for (i = 0; i < size; i++) {
			*(char *)(buffer + i) = input_getc();
		}

		return (uint32_t)i;
	}

	return -1;
}

int  write_actual (int fd, const void *buffer, unsigned size) {

	if (buffer == NULL) return -1;

	if (fd == 1) {
		putbuf(buffer,size);
		return (uint32_t)size;
	}

	return -1;
}

int exec_actual (const char *cmd_line) {

	if (sysDebug == true)
		printf("\t\tEXEC_ACTUAL!!!!!!\n");

	int t = process_execute(cmd_line);
	return t;

}

int wait_actual (int pid) {
	
	int t = process_wait(pid);
	return t;

}

int sum_actual (int a, int b, int c, int d) {

	return a + b + c + d;

}

int pibonacci_actual (int a) {

	int n1, n2, n3;
	int i;

	n1 = 0;
	n2 = 1;
	n3 = 1;

	if (a == 1) return 1;

	for (i = 1; i < a; i++) {
		n3 = n1 + n2;
		n1 = n2;
		n2 = n3;
	}

	return n3;
}

/*
	Initial Source
*/

void *get_argument (struct intr_frame *f UNUSED, int n, int exp) {

	if (exp == 0x4) {
		return (f->esp + (exp * n));
	} else if (exp == 0x1) {
		return ((int *)f->esp + exp);
	}

	return f->esp + (exp * n);
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{

	/* Here is my source */
	if (f->esp == NULL || ((uint32_t)(f->esp) + (uint32_t)4) >= (uint32_t)0xc0000000)
		exit_actual(-1);
	
	int idx = *(int *)f->esp;

	if (sysDebug == true && idx == SYS_EXEC) {
		printf("\t\tBe Careful!! Execution Will be launched!!\n");
	}

	switch (idx) {
		case SYS_HALT: halt_actual(); break;
		case SYS_READ: f->eax = read_actual(	*(int *)get_argument(f,1,0x4),
							*(void **)get_argument(f,2,0x4),
					     		*(unsigned *)get_argument(f,3,0x4));
			       break;
		case SYS_WRITE:f->eax = write_actual(	*(int *)get_argument(f,1,0x4),
							*(const void **)get_argument(f,2,0x4),	
							*(unsigned *)get_argument(f,3,0x4));
			       break;
		case SYS_EXIT: exit_actual(*(int *)get_argument(f,1,0x4)); break;
		case SYS_EXEC: f->eax = exec_actual(*(const char **)get_argument(f,1,0x1)); break;
		case SYS_WAIT: f->eax = wait_actual(*(int *)get_argument(f,1,0x4)); break;
		case SYS_SUM:  f->eax = sum_actual(	*(int *)get_argument(f,1,0x4),
							*(int *)get_argument(f,2,0x4),
							*(int *)get_argument(f,3,0x4),
							*(int *)get_argument(f,4,0x4)); break;
		case SYS_PIBO: f->eax =pibonacci_actual(*(int *)get_argument(f,1,0x4)); break;
	}

	/* End of My Source */

}
